import PIL.Image


def ImageCrop(args):
    img = PIL.Image.open(args[0])
    b = (64, 283, 661, 629)
    croppedImage = img.crop(box=b)
    croppedImage.save(args[1])
