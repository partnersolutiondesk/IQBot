def getFirstline(arg):
    with open(arg) as f:
        first_line = f.readline().strip('\n')
    return first_line
